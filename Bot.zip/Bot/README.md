<div align="center">
    <img alt="alfbot" src ="https://user-images.githubusercontent.com/75715231/101639693-2d879b80-3a62-11eb-9416-4ec708b32442.jpg" width="320">
    <h3> BOT WHATSAPP YANG BISA DIGUNAKAN DI TERMUX </h3>
# 
    Zero x Bot
</div>


## CARA INSTALL

### TERMUX
```bash
> download termux
> buka
> pkg install git
> git clone https://github.com/Bad-Boyz-ID/Zero-x-Bot
> cd Zero-x-Bot
> bash install.sh
> node index.js
```


## FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS 
|       ✅       | OCR                               |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,TWT,TIK TOK DOWNLOADER   |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |

✅ aktif


## THANKS TO

## DONASI
* [`Dana`](085700925421)